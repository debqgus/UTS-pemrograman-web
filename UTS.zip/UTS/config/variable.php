<?php 
$config['hostname'] = 'localhost';
$config['username'] = 'root';
$config['password'] = NULL;
$config['database'] = 'todolist';
$config['port'] = NULL;
?>