<?php 
include $_SERVER['DOCUMENT_ROOT'].'/config/db.php';

function get_all_data($table){
    global $conn;
    $query = "SELECT * FROM $table";
    $result = mysqli_query($conn, (mysqli_real_escape_string($conn, $query)));
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
        
    }
    return $rows;
}
function get_data($table, $where_clause)
{
    global $conn;
    $query = "SELECT * FROM $table $where_clause LIMIT 1";
    $result = mysqli_query($conn, (mysqli_real_escape_string($conn, $query)));
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
        
    }
    return $rows[0];
}
function insert($table, $data)
{
    global $conn;
    unset($data['submit']);
    $columns='';
    $placeholder='';
    foreach ($data as $key => $value) {
        $columns.="`$key`".',';
        $placeholder.="'".$value."'".',';

    }
    $columns  = rtrim($columns, ',');
    $placeholder = rtrim($placeholder, ',');
    $query = "INSERT INTO `$table` ($columns) VALUES ($placeholder)";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}
function update($table, $data, $where_clause)
{
    global $conn;
    unset($data['submit']);
    $set_clause= '';
    foreach ($data as $key => $value){
        $set_clause .= "`$key` = '$value',";
    }
    $set_clause = rtrim($set_clause, ' ,');
    $query = "UPDATE $table SET $set_clause $where_clause";
    return mysqli_affected_rows($conn);

}
function delete($table, $where_clause){
    global $conn;
    $query= "DELETE FROM $table $where_clause";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}
?>