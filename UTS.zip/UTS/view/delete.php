<?php
include $_SERVER['DOCUMENT_ROOT'] . '/controller/process.php';
$id = htmlspecialchars($_GET['id']);
if (delete('todo', "WHERE id = $id") > 0) {
    echo "<script>alert('Data berhasil dihapus!!');location.href='./index.php'</script>";
} else {
    echo "<script>alert('Data gagal dihapus!!');location.href='./index.php'</script>";
}
die();
?>